#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

char *note_content = NULL;

void setup() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void menu() {
    printf("\n--- Ghost Writer Storage ---\n");
    printf("1. Write Note (Malloc)\n");
    printf("2. Delete Note (Free)\n");
    printf("3. Read Note (Use)\n");
    printf("4. Store Secret (Admin Only)\n");
    printf("5. Exit\n");
    printf("> ");
}

void write_note() {
    note_content = malloc(64);
    printf("Pointer allocated at: %p\n", note_content);
    printf("Enter content: ");
    read(0, note_content, 63);
    printf("Note saved.\n");
}

void delete_note() {
    if (note_content) {
        free(note_content);
        printf("Note deleted!\n");
        
       : note_content = NULL;
    } else {
        printf("No note to delete.\n");
    }
}

void read_note() {
    (Use-After-Free)
    if (note_content) {
        printf("Content: %s\n", note_content);
    } else {
        printf("No note to read.\n");
    }
}

void store_secret() {
    printf("Admin authenticating...\n");
    printf("Allocating memory for secret...\n");
    
    char *secret = malloc(64);
    
    FILE *f = fopen("flag.txt", "r");
    if (f) {
        fgets(secret, 64, f);
        fclose(f);
    } else {
        strcpy(secret, "HexDefender{TEST_FLAG}");
    }
    
    printf("Secret stored securely in memory (at %p).\n", secret);
}

int main() {
    setup();
    int choice;
    while(1) {
        menu();
        if(scanf("%d", &choice) != 1) break;
        getchar(); 
        
        switch(choice) {
            case 1: write_note(); break;
            case 2: delete_note(); break;
            case 3: read_note(); break;
            case 4: store_secret(); break; 
            case 5: exit(0);
            default: printf("Invalid choice\n");
        }
    }
    return 0;
}
