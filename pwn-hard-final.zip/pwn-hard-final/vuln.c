#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void setup() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
}

void aux() {
    __asm__("pop %rdi; ret");
    __asm__("pop %rsi; ret");
    __asm__("pop %rdx; ret");
}

void start() {
    char buffer[64];
    
    puts("\n=== Hex Defender Library Maze ===");
    printf("Enter payload: ");
    
    read(0, buffer, 0x200);
}

int main() {
    setup();
    start();
    return 0;
}
